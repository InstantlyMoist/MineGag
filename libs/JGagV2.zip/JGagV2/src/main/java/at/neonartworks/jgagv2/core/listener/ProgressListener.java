package at.neonartworks.jgagv2.core.listener;

public interface ProgressListener
{
	void progress(float percentage);
}
