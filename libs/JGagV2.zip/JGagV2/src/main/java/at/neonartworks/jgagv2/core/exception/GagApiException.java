package at.neonartworks.jgagv2.core.exception;

public class GagApiException extends Exception
{

	private static final long serialVersionUID = -7630960880486594477L;

	public GagApiException()
	{
	}

}
